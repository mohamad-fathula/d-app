package com.example.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;


public class MyDB extends SQLiteOpenHelper {

    Context c;
   public static String DATABASE="userdatabase";
    public static int VERSION=1;
    public MyDB(Context context){
   super(context,DATABASE,null,VERSION);
   c=context;

    }


 @Override
    public void onCreate(SQLiteDatabase db) {
        try {
    String qry =
      "create table user (fname TEXT , Lname TEXT, pass TEXT, Phone TEXT, email TEXT PRIMARY KEY,DRorP TEXT)";
      db.execSQL(qry);
      Toast.makeText(c,"table created",Toast.LENGTH_LONG).show();
        }


        catch (Exception e){
Log.e("MYDB","Table errore",e);
        }
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public Boolean insertdata( String fname,String lname, String pass , String phone , String email,String DRorP)
    {
        try{
String qry="insert into user  values ('"+fname+"' , '"+lname+"', '"+pass+"' ,'"+phone+"' , '"+email+"' , '"+DRorP+"')";
SQLiteDatabase db=getWritableDatabase();
db.execSQL(qry);
            Toast.makeText(c,fname+ " registered",Toast.LENGTH_LONG).show();
            return true;
        }

        catch (Exception e){
            Log.e("MYDB","record error",e);
            return  false;
        }
    }





    public Cursor LoginCheck(String Email){
        try{
            String qry=" Select email , pass ,DRorP from user where email ='"+Email+"' ";
            SQLiteDatabase db=getWritableDatabase();
            Cursor c=db.rawQuery(qry,null);
            return c;

        }

        catch (Exception e){
            Log.e("MYDB", "login Error",e);
            return null;
        }
    }


}


