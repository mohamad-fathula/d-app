package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    static MyDB myDB;
    EditText name,pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=(EditText)findViewById(R.id.username);
        pass=(EditText)findViewById(R.id.password);
        myDB = new MyDB(this);

    }

    public void loginCheck(View v) {

        String email = name.getText().toString().trim();
        String passwordd = pass.getText().toString().trim();
        Cursor c = MainActivity.myDB.LoginCheck(email);

        c.moveToFirst();

        if (c == null) {
            Toast.makeText(MainActivity.this, "invalid " + email, Toast.LENGTH_LONG).show();
            name.setText("");
            pass.setText("");
        }
        else {
            String name2 = c.getString(0);
            String pass2 = c.getString(1);
            String dr=c.getString(2);


            if (passwordd.equals(pass2)) {

                if(dr.equals("دکتۆر")) {
                    Intent i = new Intent(MainActivity.this, DrActivity.class);
                    i.putExtra("name", name2);
                    startActivity(i);
                }

                else {
                    Intent i = new Intent(MainActivity.this, ll.class);
                    i.putExtra("name", name2);
                    startActivity(i);
                }

         }

            else {
                Toast.makeText(MainActivity.this, "invalid ", Toast.LENGTH_LONG).show();
            }
            name.setText("");
            pass.setText("");
        }

    }







    public void register(View view){
        Intent i=new Intent(MainActivity.this,RegisterActivity.class);
     startActivity(i);
    }


}
