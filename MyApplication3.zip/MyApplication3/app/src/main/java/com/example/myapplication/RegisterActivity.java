package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText et1, et2, et3, et4, et5;
    static MyDB myDB;


    RadioGroup radioGroup;
    RadioButton radioButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        et1 = (EditText) findViewById(R.id.fname);
        et2 = (EditText) findViewById(R.id.lname);
        et3 = (EditText) findViewById(R.id.pass1);
        et4 = (EditText) findViewById(R.id.phone);
        et5 = (EditText) findViewById(R.id.email);
        radioGroup=findViewById(R.id.radiogroup);

    }

    public void savedata(View v){


        int radioID=radioGroup.getCheckedRadioButtonId();
        radioButton =findViewById(radioID);

        String fname = et1.getText().toString().trim();
        String lname = et2.getText().toString().trim();
        String pass = et3.getText().toString().trim();
        String phone = et4.getText().toString().trim();
        String email = et5.getText().toString().trim();
        String radio=radioButton.getText().toString().trim();

        Boolean result=MainActivity.myDB.insertdata(fname,lname,pass,phone,email,radio);


        if (result){
            Toast.makeText(RegisterActivity.this, lname+"  " + radio +"register success",Toast.LENGTH_LONG).show();
            et1.setText("");
            et2.setText("");
            et3.setText("");
            et4.setText("");
        }

        else {
            AlertDialog.Builder ad=new AlertDialog.Builder(this);
            ad.setMessage("wrong input");
            ad.show();
        }
        et5.setText("");
    }


    public void goback(View v){
        Intent i=new Intent(RegisterActivity.this,MainActivity.class);
        startActivity(i);
    }
    }

